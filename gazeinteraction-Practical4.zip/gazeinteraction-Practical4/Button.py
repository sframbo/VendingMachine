import cv2
import numpy as np


class Button():

    def __init__(self):
        pass

    def draw(self, gaze, img: np.array):
        pass

